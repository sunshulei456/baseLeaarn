package com.klk.rest.distribute.util;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

public class BizIdGenerator {

    //初始为100，即3位长度
    private static final AtomicInteger SEQ = new AtomicInteger(100);
    private static final DateTimeFormatter DF_FMT_PREFIX = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSS");
    private static final ZoneId ZONE_ID = ZoneId.of("Asia/Shanghai");

    /**
     * 仅作为测试服务中的生成策略
     * 项目中业务返回的虚伪数据在消费系统的真实的业务ID
     * @return
     */
    public static String generate(){
        LocalDateTime dataTime = LocalDateTime.now(ZONE_ID);
        if (SEQ.intValue() > 9990) {
            SEQ.getAndSet(1000);
        }
        return dataTime.format(DF_FMT_PREFIX) + SEQ.getAndIncrement();
    }
}
