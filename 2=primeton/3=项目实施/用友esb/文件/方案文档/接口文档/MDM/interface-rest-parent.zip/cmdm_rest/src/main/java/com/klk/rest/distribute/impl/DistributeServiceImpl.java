package com.klk.rest.distribute.impl;

import com.alibaba.fastjson.JSON;
//import com.alibaba.fastjson.JSONObject;
import com.klk.rest.distribute.entity.*;
import com.klk.rest.distribute.IDistributeService;
import com.klk.rest.distribute.util.BizIdGenerator;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 对主数据进行消费的服务层
 */
public class DistributeServiceImpl implements IDistributeService {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public DistributeRetVO distributeMd(DistributePostDataVO distributePostDataVO) {

        DistributeRetVO retVO = new DistributeRetVO();
        String content = "masterData为：" + distributePostDataVO.getMasterData() + "。SystemCode为：" + distributePostDataVO.getSystemCode() + "。mdType为：" + distributePostDataVO.getMdType() + "。action为：" + distributePostDataVO.getAction() + "。distributeToken为：" + distributePostDataVO.getDistributeToken();
//        System.out.println("本次数据分发结构内容为：" + JSON.toJSONString(distributePostDataVO));

        SimpleDateFormat dateFormat = new SimpleDateFormat("ss");
        String filename = dateFormat.format(new Date());
        // 可将接收到的数据进行简单校验、存库、写入文件等业务操作
        writeToFile(content, filename);

        // JSONString格式的主数据解析
        List<Map<String, Object>> masterDataList = toMapList(distributePostDataVO.getMasterData());
        if (masterDataList != null) {
            System.out.println("数据量为：" +masterDataList.size());
        }

        // 构造主数据在消费系统的血缘关系，即业务ID映射数据
        List<MdMapingVO> bizIdMappingList = generateMappingData(distributePostDataVO.getMdType(), masterDataList);
        retVO.setMdMappings(bizIdMappingList);

        retVO.setSuccess(false);
        retVO.setMessage("数据消费已处理！");
        // 由于数据分发需要同步等待消费系统返回体
        // 所以可提高主数据系统的数据分发吞吐量，减少延时等待
        return retVO;
    }


    /**
     * 将JSONString格式主数据，解析为MapList格式
     * @param jsonStr
     * @return
     */
    public static List<Map<String, Object>> toMapList(String jsonStr){
        JSONArray masterDataArray = JSONArray.fromObject(jsonStr);

        List< Map<String,Object>> dataMapList = new ArrayList<>(masterDataArray.size());
        for (Object object : masterDataArray.toArray()){
            JSONObject json = (JSONObject) object;
            Map<String, Object> dataMap = new HashMap<>(json.keySet().size());
            for (Object key : json.keySet()) {
                dataMap.put(String.valueOf(key), json.get(key));
            }
            dataMapList.add(dataMap);
        }
        return dataMapList;

    }

    /**
     * 构造主数据列表的血缘关系
     * 本DEMO使用生成的伪随机数代替真实的业务ID
     * @param entityCode
     * @param masterDataList
     * @return
     */
    private List<MdMapingVO> generateMappingData(String entityCode, List<Map<String, Object>> masterDataList) {
        List<MdMapingVO> mappingDataList = new ArrayList<>(masterDataList.size());
        for (Map<String, Object> dataMap : masterDataList) {
            MdMapingVO mapping = new MdMapingVO();
            mapping.setEntityCode(entityCode);
            mapping.setMdmCode((String) dataMap.get("mdm_code"));
            // 本DEMO使用生成的伪随机数代替真实的业务ID
            // 真实的业务ID为此条主数据在消费系统的唯一值，如主键、唯一编码等等
            mapping.setBusiDataId(BizIdGenerator.generate());
            // 可单独指定此条数据消费成功或失败
            boolean ifSuccess = (int) (Math.random() * 100) % 2 == 0;
            mapping.setSuccess(ifSuccess);
//            mapping.setSuccess(true);
            // 可单独指定此条数据消费的详情消息
            if (ifSuccess) {
                mapping.setMessage("校验并消费成功");
            } else {
                mapping.setMessage("消费失败");
            }
            mappingDataList.add(mapping);
        }
        return mappingDataList;
    }


    /**
     * 根据不同的操作系统，将接收到的主数据写入磁盘文件中
     * @param md                接受到的主数据
     * @param filename          写入的文件名
     */
    private void writeToFile(String md, String filename) {
        String OS = System.getProperty("os.name").toLowerCase();
        String dir = "";
        if (OS.indexOf("linux") >= 0) {
            dir = "/data/rest_receive/";
        } else if (OS.indexOf("windows")>=0){
            dir = "e:/rest_receive/";
        }

        File file = new File(dir);
        if (!file.exists()) {
            file.mkdirs();
        }
        filename = dir + filename + ".txt";
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new
                    FileWriter(filename));
            writer.write(md);
        } catch (Exception e) {
            throw new RuntimeException("输出主数据到文件失败 : " + filename, e);
        } finally {
            try {
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        System.out.println((int) (Math.random() * 100));
    }

}
