package com.yonyou.iuap.centerservice.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

public class MdmQueryVO implements Serializable, Cloneable {

    private static final long serialVersionUID = -1551345844610717787L;
    private String systemCode;
    private String gdCode;
    private List<String> codes;
    private JSONObject conditions; // 查询条件 JSONObject

    public MdmQueryVO() {
        super();
    }

    public String getSystemCode() {
        return systemCode;
    }

    public void setSystemCode(String systemCode) {
        this.systemCode = systemCode;
    }

    public String getGdCode() {
        return gdCode;
    }

    public void setGdCode(String gdCode) {
        this.gdCode = gdCode;
    }

    public List<String> getCodes() {
        return codes;
    }

    public void setCodes(List<String> codes) {
        this.codes = codes;
    }

    public JSONObject getConditions() {
        return conditions;
    }

    public void setConditions(JSONObject conditions) {
        this.conditions = conditions;
    }

    @Override
    public String toString() {
        return "MdmQueryVO [systemCode=" + systemCode + ", gdCode=" + gdCode
                + ", mdmCodes=" + codes + "]";
    }

    @SuppressWarnings("unchecked")
    @Override
    public MdmQueryVO clone() throws CloneNotSupportedException {
        MdmQueryVO clone = (MdmQueryVO) super.clone();
        ArrayList<String> codes = new ArrayList<String>(this.codes);
        ArrayList<String> codesClone = (ArrayList<String>) codes.clone();
        clone.setCodes(codesClone);
        return clone;
    }

}
