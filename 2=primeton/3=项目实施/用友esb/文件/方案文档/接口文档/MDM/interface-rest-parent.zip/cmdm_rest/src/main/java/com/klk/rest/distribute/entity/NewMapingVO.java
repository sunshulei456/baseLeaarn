package com.klk.rest.distribute.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NewMapingVO implements Serializable {

    private boolean success;
    private String message;
    private String mdmCode;
    private String entityCode;
    private String busiDataId;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMdmCode() {
        return mdmCode;
    }

    public void setMdmCode(String mdmCode) {
        this.mdmCode = mdmCode;
    }

    public String getEntityCode() {
        return entityCode;
    }

    public void setEntityCode(String entityCode) {
        this.entityCode = entityCode;
    }

    public String getBusiDataId() {
        return busiDataId;
    }

    public void setBusiDataId(String busiDataId) {
        this.busiDataId = busiDataId;
    }
}
