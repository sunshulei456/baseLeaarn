package com.klk.rest.distribute.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NewRetVO implements Serializable {


    private List<NewMapingVO> mdMappings;

    public List<NewMapingVO> getMdMappings() {
        return mdMappings;
    }

    public void setMdMappings(List<NewMapingVO> mdMappings) {
        this.mdMappings = mdMappings;
    }

}
