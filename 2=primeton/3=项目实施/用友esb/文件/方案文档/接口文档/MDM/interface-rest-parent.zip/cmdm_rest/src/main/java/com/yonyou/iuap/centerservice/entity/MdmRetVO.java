package com.yonyou.iuap.centerservice.entity;

import java.io.Serializable;



public class MdmRetVO implements Serializable, Cloneable {

    private static final long serialVersionUID = -2175682495640549939L;

    /**
     * 返回的主数据(json\xml)
     */
    private String data;

    private String code;

    private Object obj;

    /**
     * MDM与第三方系统交互成功与否
     */
    private boolean success;

    /**
     * 结果描述信息
     */
    private String message;

    public MdmRetVO() {
        super();
    }

    public MdmRetVO(String data, boolean success, String message, String code) {
        super();
        this.data = data;
        this.success = success;
        this.message = message;
        this.code = code;
    }


    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getObj() {
        return obj;
    }

    public void setObj(Object obj) {
        this.obj = obj;
    }

    @Override
    public MdmRetVO clone() throws CloneNotSupportedException {
        MdmRetVO clone = (MdmRetVO) super.clone();
        //clone.obj = this.obj;该方法并不携带obj这个对象
        return clone;
    }

    public String toString() {
        return "-----------" + this.getMessage();
    }
}
