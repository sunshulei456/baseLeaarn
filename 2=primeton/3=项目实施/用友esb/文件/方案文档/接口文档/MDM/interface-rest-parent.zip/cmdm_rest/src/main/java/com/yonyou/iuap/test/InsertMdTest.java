package com.yonyou.iuap.test;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.Random;

/**
 * 测试insertMd接口的详细测试代码和说明
 * demo代码说明了如何往主数据模型（人员信息）中，通过insertMd的rest接口，插入主数据
 */
public class InsertMdTest {

    private void testInsertMd() throws IOException {
        //insertMd服务的路径，即主数据产品集成标准中提供的地址
        String url = "http://127.0.0.1:8080/iuapmdm/cxf/mdmrs/newcenter/newCenterService/insertMd";
        //人员主数据的主数据编码
        String gdCode = "person_info";
        //能够访问人员主数据的远程系统编码
        String systemCode = "system01";
        HttpPost post = new HttpPost(url);
        //HttpPost的配置
        RequestConfig requestConfig = RequestConfig.custom()
                .setSocketTimeout(60000)
                .setConnectTimeout(60000)
                .setConnectionRequestTimeout(10000)
                .build();
        //genInsertVO方法构建了insertMd的接收json结构的数据
        StringEntity requestEntity = new StringEntity(genInsertVO(gdCode, systemCode).toString(), "utf-8");
        requestEntity.setContentType(ContentType.APPLICATION_JSON.toString());
        post.setConfig(requestConfig);
        post.setEntity(requestEntity);
        //HttpPost的header中需要传递的两个参数

        //tenantid字段是当前系统的租户ID，若为专属化部署的主数据系统，值为tenant；若使用的是公有云的主数据系统就，值为产品的集成标准中tenantid的备注中的值
        post.setHeader("tenantid", "tenant");
        //mdmtoken是远程系统的token，也就是system01这个远程系统在主数据中设置的token
        post.setHeader("mdmtoken", "eb2e7631-1b5a-4c17-b8c5-7fa5eddff37f");

        CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpResponse response = httpClient.execute(post);
        HttpEntity entity = response.getEntity();
        String resp = EntityUtils.toString(entity, "utf-8");
        System.out.println(resp);
        //返回结果
        //{"data":"[{\"name\":\"张三\",\"id\":\"id219943341\",\"OPERATION_TYPE\":\"INSERT\",\"mdm_code\":\"person_info00000039\"},{\"name\":\"张三\",\"id\":\"id968917275\",\"OPERATION_TYPE\":\"INSERT\",\"mdm_code\":\"person_info00000040\"}]","code":null,"obj":null,"success":true,"message":"本次主表装载成功2条，失败0条。子表[job]装载成功2条，失败0条。"}
    }

    /**
     * 构建一条主数据的json对象
     *
     * @return
     */
    private static JSONObject getData() {
        JSONObject data = new JSONObject();
        //主表的数据  id是业务id，是接口调用必须传递的参数，为这条主数据的唯一标志，后面如果需要修改或者查询，可以通过这个id
        data.put("id", "id" + new Random().nextInt(1000000000));
        data.put("name", "张三");
        //参照和下拉的设置方法，person_org这个数据参照了一个组织的主数据，我们可以设置参照的查找方式，
        //person_org#name,表示通过组织的name来查找组织，后面需要传递这个组织的名称（用友集团），如果传递用友集团这个组织的code，就会报错
        //假如设置person_org#code,表示通过code来查找组织
        //如果设置为person_org，没有指定参照的查找方式，则必须传递这个参照（组织）的mdmCode
        data.put("person_org#name", "用友集团");
        data.put("code", "zhangsan");
        //dr这个标志，如果传1，代表删除数据。默认插入和更新数据的时候，不用传
        //data.put("dr", "1");
        //mdm_datastatus这个属性，用来封存和解封数据，默认不用传递"3"是解封  "4"是封存，只能是这两个数值。
        // 一般除了需要封存主数据外，也不用传
        //   data.put("mdm_datastatus", "4");

        //设置子表（sub_的前缀，加上子表的code），的json对象，这个人员信息有个code为job的的子表，就需要传递sub_job,加入还有family的子表，同理传递sub_familyd的子表信息
        data.put("sub_job", "");
        //通过JSONArray来存储多条子表的数据
        JSONArray sub = new JSONArray();
        JSONObject subData = new JSONObject();
        subData.put("id", "id" + new Random().nextInt(1000000000));
        subData.put("name", "李四");
        subData.put("code", "lisi");
        subData.put("job_org#name", "用友集团");
        sub.add(subData);
        data.put("sub_job", sub);
        return data;
    }

    private JSONObject genInsertVO(String gdCode, String systemCode) {
        JSONArray masterData = new JSONArray();
        //通过JSONArray，传递了两条主数据
        for (int i = 0; i < 2; i++) {
            masterData.add(getData());
        }
        //最后构建insetMd接口需要的json对象，具体属性可以参照MdmInsertVO这个对象
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("systemCode", systemCode);
        jsonObject.put("gdCode", gdCode);
        jsonObject.put("masterData", masterData);
        return jsonObject;
    }

    public static void main(String[] args) {
        InsertMdTest test = new InsertMdTest();
        try {
            test.testInsertMd();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
