package com.klk.rest.distribute.entity;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

/**
 * 数据分发的数据体格式
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DistributePostDataVO implements Serializable{

	private static final long serialVersionUID = -923702730339876372L;

	/**
	 * 接收此数据的消费系统编码
	 */
	private String systemCode;

	/**
	 * 此数据所属的主数据模型编码
	 */
	private String mdType;

	/**
	 * 数据分发的触发类型：
	 * DISTRIBUTE-MANUAL			手动数据分发
	 * DISTRIBUTE-SUBSCRIBE			数据新增更新等触发的订阅分发
	 * DISTRIBUTE_CRON				定时任务的自动分发
	 * DISTRIBUTE-MANUAL-RESEND 	分发日志中手动重发
	 * DISTRIBUTE-AUTO-RESEND		分发失败后，自动重新分发
	 */
	private String action;

	/**
	 * JSONString格式的主数据列表
	 */
	private String masterData;

	/**
	 * 该消费系统所配置的分发认证TOKEN
	 * 消费系统可对接收到的Token值进行校验
	 */
	private String distributeToken;

	/**
	 * 审批的分发编码， 2:审批拒绝
	 */
	private int code;

	/**
	 * 分发的数据的审批消息 审批拒绝时非空
	 */
	private String msg;

	public DistributePostDataVO() {
		super();
	}
	public DistributePostDataVO(String systemCode, String mdType, String action,
			String masterData) {
		super();
		this.systemCode = systemCode;
		this.mdType = mdType;
		this.action = action;
		this.masterData = masterData;
	}
	public DistributePostDataVO(String systemCode, String mdType, String action,
								String masterData, String distributeToken) {
		super();
		this.systemCode = systemCode;
		this.mdType = mdType;
		this.action = action;
		this.masterData = masterData;
		this.distributeToken = distributeToken;
	}
	public String getSystemCode() {
		return systemCode;
	}
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}
	public String getMdType() {
		return mdType;
	}
	public void setMdType(String mdType) {
		this.mdType = mdType;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getMasterData() {
		return masterData;
	}
	public void setMasterData(String masterData) {
		this.masterData = masterData;
	}

	public String getDistributeToken() {
		return distributeToken;
	}

	public void setDistributeToken(String distributeToken) {
		this.distributeToken = distributeToken;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}
