MDM DISTRIBUTION FUNCTION DEMO

主数据分发能力Demo项目

====================================================================================================


主数据分发功能接口API

主数据所需的分发标准服务接口包：com.yonyou.iuapmdm.distributeservice

主数据规定的分发接口：com.yonyou.iuapmdm.distributeservice.service.IDistributePostService

以及接口中需要的分发推送对象：com.yonyou.iuapmdm.distributeservice.entity.DistributePostDataVO

接口中需要返回的分发返回对象：com.yonyou.iuapmdm.distributeservice.entity.DistributeRetVO

主数据中消费webService服务Demo：com.yonyou.iuapmdm.distributeservice.util.ConsumeWebServiceByApacheCXF


====================================================================================================


第三方系统实现方式Demo工程

第三方系统实现所在包为：com.threepartysystem.xxproject.distributedemo

第三方系统实现主数据规定的分发接口：com.threepartysystem.xxproject.distributedemo.server.impl.DistributePostServiceImpl

第三方系统将实现服务发布webService服务Demo：com.threepartysystem.xxproject.distributedemo.util.PublishWebServiceByApacheCXF