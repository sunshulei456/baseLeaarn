package com.klk.rest.distribute.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

/**
 * 每条数据的血缘关系结构
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MdMapingVO implements Serializable{

	private static final long serialVersionUID = -5488253314295792733L;

	/**
	 * 此条数据的主数据编码（MDM_CODE）
	 * 必填项
	 */
	private String mdmCode;

	/**
	 * 主数据模型的编码
	 * 必填项
	 */
	private String entityCode;

	/**
	 * 此条数据在消费系统的业务ID，唯一值
	 * 必填项
	 */
	private String busiDataId;

	/**
	 * 此条数据是否被消费成功
	 * 此值会覆盖DistributeRetVO中的success TODO 验证
	 * 非必填
	 */
	private Boolean success;

	/**
	 * 此条数据被消费的详细信息
	 * 非必填
	 */
	private String message;


	public MdMapingVO() {
		super();
	}
	public MdMapingVO(String mdmCode, String entityCode, String busiDataId) {
		super();
		this.mdmCode = mdmCode;
		this.entityCode = entityCode;
		this.busiDataId = busiDataId;
	}
	public String getMdmCode() {
		return mdmCode;
	}
	public void setMdmCode(String mdmCode) {
		this.mdmCode = mdmCode;
	}
	public String getEntityCode() {
		return entityCode;
	}
	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}
	public String getBusiDataId() {
		return busiDataId;
	}
	public void setBusiDataId(String busiDataId) {
		this.busiDataId = busiDataId;
	}

	public Boolean getSuccess() {
		return success;
	}

	public void setSuccess(Boolean success) {
		this.success = success;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "MdMapingVO [mdmCode=" + mdmCode + ", entityCode=" + entityCode
				+ ", busiDataId=" + busiDataId + "]";
	}
	
}
