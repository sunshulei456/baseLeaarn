package com.klk.rest.distribute;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.klk.rest.distribute.entity.DistributePostDataVO;
import com.klk.rest.distribute.entity.DistributeRetVO;
import com.klk.rest.distribute.entity.EsbRetVO;
import org.springframework.stereotype.Service;

/**
 * 消费系统发布的数据分发服务接口
 * 详情看beans.xml中定义的distributeRestService服务、address
 * 及指定的mdDistributeService的实现类服务
 */
@Service
@Path("/distributeService")
public interface IDistributeService {

	/**
	 * REST接口，须指定生产JSON
	 * @param postData 		主数据系统数据分发的数据结构
	 * @return				主数据系统分发返回体数据结构
	 */
	@POST
	@Path("/distributeMd")
	@Produces({MediaType.APPLICATION_JSON})
	DistributeRetVO distributeMd(DistributePostDataVO postData);

}
