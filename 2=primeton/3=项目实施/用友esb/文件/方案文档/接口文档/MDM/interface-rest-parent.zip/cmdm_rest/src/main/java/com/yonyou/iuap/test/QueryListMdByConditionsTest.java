package com.yonyou.iuap.test;

import net.sf.json.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 测试QueryListMdByConditions接口的详细测试代码和说明
 */
public class QueryListMdByConditionsTest {

    private void testQuery() throws IOException {
        //服务的路径，即主数据产品集成标准中提供的地址
        String url = "http://127.0.0.1:8000/iuapmdm/cxf/mdmrs/newcenter/newCenterService/queryListMdByConditions";
        //人员主数据的主数据编码
        String gdCode = "person_info";
        //能够访问人员主数据的远程系统编码
        String systemCode = "system01";
        HttpPost post = new HttpPost(url);
        //HttpPost的配置
        RequestConfig requestConfig = RequestConfig.custom()
                .setSocketTimeout(60000)
                .setConnectTimeout(60000)
                .setConnectionRequestTimeout(10000)
                .build();
        //genQueryVO方法构建json结构的MdmQueryVO的json对象
        StringEntity requestEntity = new StringEntity(genQueryVO(gdCode, systemCode).toString(), "utf-8");
        requestEntity.setContentType(ContentType.APPLICATION_JSON.toString());
        post.setConfig(requestConfig);
        post.setEntity(requestEntity);
        //HttpPost的header中需要传递的两个参数

        //tenantid字段是当前系统的租户ID，若为专属化部署的主数据系统，值为tenant；若使用的是公有云的主数据系统就，值为产品的集成标准中tenantid的备注中的值
        post.setHeader("tenantid", "tenant");
        //mdmtoken是远程系统的token，也就是system01这个远程系统在主数据中设置的token
        post.setHeader("mdmtoken", "13e3cbd1-d90e-4956-8a1f-272a07ea5f2e");

        CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpResponse response = httpClient.execute(post);
        HttpEntity entity = response.getEntity();
        String resp = EntityUtils.toString(entity, "utf-8");
        System.out.println(resp);
        //返回数据
        //{"data":"[{\"person_org\":\"person_org00000001\",\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:47:30\",\"code\":\"zhangsan\",\"modifytime\":\"2019-12-21 11:47:30\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"person_org_name\":\"用友集团\",\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"person_info00000037\",\"mdm_version\":1,\"name\":\"张三\",\"id\":\"id366470330\",\"sub_job\":[{\"isHistory\":false,\"isWorkflow\":false,\"data\":{\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:47:30\",\"code\":\"lisi\",\"modifytime\":\"2019-12-21 11:47:30\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"job00000020\",\"mdm_parentcode\":\"person_info00000037\",\"job_org\":\"person_org00000001\",\"mdm_version\":1,\"name\":\"李四\",\"id\":\"id663714154\",\"job_org_name\":\"用友集团\",\"pk_mdm\":\"cd9f7a88-19a4-4a57-991c-44e538d4682b\"}}],\"pk_mdm\":\"853246de-ad48-43fb-bd72-94f96779aef0\"},{\"person_org\":\"person_org00000001\",\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:47:30\",\"code\":\"zhangsan\",\"modifytime\":\"2019-12-21 11:47:30\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"person_org_name\":\"用友集团\",\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"person_info00000038\",\"mdm_version\":1,\"name\":\"张三\",\"id\":\"id261635674\",\"sub_job\":[{\"isHistory\":false,\"isWorkflow\":false,\"data\":{\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:47:30\",\"code\":\"lisi\",\"modifytime\":\"2019-12-21 11:47:30\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"job00000021\",\"mdm_parentcode\":\"person_info00000038\",\"job_org\":\"person_org00000001\",\"mdm_version\":1,\"name\":\"李四\",\"id\":\"id724424643\",\"job_org_name\":\"用友集团\",\"pk_mdm\":\"844dac4f-ca55-45d9-82c3-8c4f7e115752\"}}],\"pk_mdm\":\"3c8ee66a-45f3-41e6-9abb-c2e1b85b2eb1\"},{\"person_org\":\"person_org00000001\",\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:46:58\",\"code\":\"zhangsan\",\"modifytime\":\"2019-12-21 11:46:58\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"person_org_name\":\"用友集团\",\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"person_info00000035\",\"mdm_version\":1,\"name\":\"张三\",\"id\":\"id506567283\",\"sub_job\":[{\"isHistory\":false,\"isWorkflow\":false,\"data\":{\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:46:58\",\"code\":\"lisi\",\"modifytime\":\"2019-12-21 11:46:58\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"job00000018\",\"mdm_parentcode\":\"person_info00000035\",\"job_org\":\"person_org00000001\",\"mdm_version\":1,\"name\":\"李四\",\"id\":\"id827150560\",\"job_org_name\":\"用友集团\",\"pk_mdm\":\"fb99571a-33b2-458d-986b-fe358076681c\"}}],\"pk_mdm\":\"8b7c8492-b652-464a-8d43-901722957999\"},{\"person_org\":\"person_org00000001\",\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:46:58\",\"code\":\"zhangsan\",\"modifytime\":\"2019-12-21 11:46:58\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"person_org_name\":\"用友集团\",\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"person_info00000036\",\"mdm_version\":1,\"name\":\"张三\",\"id\":\"id125883989\",\"sub_job\":[{\"isHistory\":false,\"isWorkflow\":false,\"data\":{\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:46:58\",\"code\":\"lisi\",\"modifytime\":\"2019-12-21 11:46:58\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"job00000019\",\"mdm_parentcode\":\"person_info00000036\",\"job_org\":\"person_org00000001\",\"mdm_version\":1,\"name\":\"李四\",\"id\":\"id907585660\",\"job_org_name\":\"用友集团\",\"pk_mdm\":\"a0f1ec41-d157-47c5-9ca1-7207724d7f12\"}}],\"pk_mdm\":\"25f227d0-9a5e-4a61-a72b-6d6a055387db\"},{\"person_org\":\"person_org00000001\",\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:48:06\",\"code\":\"zhangsan\",\"modifytime\":\"2019-12-21 11:48:06\",\"modifier\":\"datainterface\",\"mdm_datastatus\":4,\"person_org_name\":\"用友集团\",\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"person_info00000039\",\"mdm_version\":1,\"name\":\"张三\",\"id\":\"id219943341\",\"sub_job\":[{\"isHistory\":false,\"isWorkflow\":false,\"data\":{\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:48:06\",\"code\":\"lisi\",\"modifytime\":\"2019-12-21 11:48:06\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"job00000022\",\"mdm_parentcode\":\"person_info00000039\",\"job_org\":\"person_org00000001\",\"mdm_version\":1,\"name\":\"李四\",\"id\":\"id786399855\",\"job_org_name\":\"用友集团\",\"pk_mdm\":\"66e5a96a-e575-44d7-aca0-25a72c96d557\"}}],\"pk_mdm\":\"83ae390f-5d26-4043-a5d5-5cb03bb1ee87\"},{\"person_org\":\"person_org00000001\",\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:48:06\",\"code\":\"zhangsan\",\"modifytime\":\"2019-12-21 11:48:06\",\"modifier\":\"datainterface\",\"mdm_datastatus\":4,\"person_org_name\":\"用友集团\",\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"person_info00000040\",\"mdm_version\":1,\"name\":\"张三\",\"id\":\"id968917275\",\"sub_job\":[{\"isHistory\":false,\"isWorkflow\":false,\"data\":{\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:48:06\",\"code\":\"lisi\",\"modifytime\":\"2019-12-21 11:48:06\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"job00000023\",\"mdm_parentcode\":\"person_info00000040\",\"job_org\":\"person_org00000001\",\"mdm_version\":1,\"name\":\"李四\",\"id\":\"id903746148\",\"job_org_name\":\"用友集团\",\"pk_mdm\":\"a170b48c-553c-4454-a882-e9d6eaed3b9c\"}}],\"pk_mdm\":\"f423ad2d-e72a-4e90-9fe5-05c8ebeaed15\"}]","code":null,"obj":null,"success":true,"message":null}
    }


    private JSONObject genQueryVO(String gdCode, String systemCode) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("systemCode", systemCode);
        jsonObject.put("gdCode", gdCode);
        //构建查询条件的json，具体规则请参考查询文档
        //这个条件为：查询主数据中name为张三的主数据
        JSONObject conditions = new JSONObject();
        List<String> cond = new ArrayList<>();
        cond.add("and");
        cond.add("=");
        //这个张三字符串中的单引号，是必须的，所有条件的具体数据值中，单引号都是必须的，否则会报错
        //后面条件说明中的条件也是一样（条件说明文档中缺少单引号）
        cond.add("'张三'");
        conditions.put("name", cond);
        jsonObject.put("conditions", conditions);
        return jsonObject;
    }

    public static void main(String[] args) {
        QueryListMdByConditionsTest test = new QueryListMdByConditionsTest();
        try {
            test.testQuery();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
/*************************************************************************************************
 *                          条件查询的说明
 *
 * Condition的值示例:
 * {"code":["AND","between","123","456"],"name":["OR","like","%中华"]}
 *
 * Conditon的值释义:
 * 即 {"字段":["AND 或者 OR","列的查询关键字","该关键字需要的值1","该关键字需要的值2"]}
 *
 * "AND 或者 OR"可以不传，默认是 AND
 *
 * Condition的释义与SQL的编译之间的对应关系
 *
 * 假设建表语句如下：
 * CREATE TABLE Persons ( Id_P int, LastName varchar(255), FirstName varchar(255), Address  varchar(255) , City varchar(255),age NUMBER
 * )
 *
 * 字符串类型（varchar）常见的操作
 *
 * 模糊查询 SQL:LastName like ‘%伟’ 查出王伟,李伟,大伟等对应的查询数据
 * {"LastName":["AND","like","李伟"]} 或者 {"LastName":["like","李伟"]}
 *
 * 完全匹配SQL:LastName = "李伟"
 * {"LastName":["AND","=","李伟"]} 或者 {"LastName":["=","李伟"]}
 *
 * 完全匹配在一批中选择一个SQL LastName in ("李伟","李伟")
 *
 * 数字类型（int,NUMBER）的常见操作
 *
 * 大于等于小于操作 SQL : age > = < 50,对应的查询数据如下
 * {"age":[">","50"]}    {"age":["=","50"]}  {"age":["<","50"]}
 *
 * 在区间之内 SQL age between 50 AND 100,
 * {"age":["between","50""100"]}直接的连接符由我们进行拼接
 *
 *
 * 主数据内部多种数据库拼接语句由主数据进行匹配,三方系统所需的的高级查询能力比较特殊的关键字,及时进行沟通,以枚举的类型添加进主数据和三方系统,以免后续的开发人员传递主数据不能识别的关键字造成异常信息
 *
 * 对于时间类型,传入java中传入Long类型的值即可
 * 大于等于小于操作 SQL : ts > = < timeValue,对应的查询数据如下
 * {"ts":[">"," timeValue"]}    {"ts":["="," timeValue"]}
 * {"ts":["<"," timeValue"]}
 * 在区间之内 SQL ts between timeValueStart AND timeValueEnd,
 * {"ts":["between"," timeValueStart"" timeValueEnd"]}
 *
 * *************************************************************************************************/

}
