package com.yonyou.iuap.centerservice.entity;

import java.util.HashMap;

public class MapBean {

    private HashMap<String, Object> beanMap;

    public HashMap<String, Object> getBeanMap() {
        return beanMap;
    }

    public void setBeanMap(HashMap<String, Object> beanMap) {
        this.beanMap = beanMap;
    }

    public final <T> T getValueByKey(String key) {
        return (T) beanMap.get(key);
    }
}
