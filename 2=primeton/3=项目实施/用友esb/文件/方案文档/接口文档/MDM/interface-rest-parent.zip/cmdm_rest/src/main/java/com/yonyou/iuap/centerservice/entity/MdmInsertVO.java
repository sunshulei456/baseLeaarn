package com.yonyou.iuap.centerservice.entity;

import net.sf.json.JSONArray;

import java.io.Serializable;

public class MdmInsertVO implements Serializable, Cloneable {

    private static final long serialVersionUID = 6047238579992167433L;
    private String systemCode;
    private String gdCode;
    private JSONArray masterData;

    public MdmInsertVO() {
        super();
    }

    public MdmInsertVO(String systemCode, String gdCode, JSONArray masterData) {
        super();
        this.systemCode = systemCode;
        this.gdCode = gdCode;
        this.masterData = masterData;
    }

    public String getSystemCode() {
        return systemCode;
    }

    public void setSystemCode(String systemCode) {
        this.systemCode = systemCode;
    }

    public String getGdCode() {
        return gdCode;
    }

    public void setGdCode(String gdCode) {
        this.gdCode = gdCode;
    }

    public JSONArray getMasterData() {
        return masterData;
    }

    public void setMasterData(JSONArray masterData) {
        this.masterData = masterData;
    }

    @Override
    public String toString() {
        return "MdmInsertVO [systemCode=" + systemCode + ", gdCode=" + gdCode
                + ", masterData=" + masterData + "]";
    }

    @Override
    public MdmInsertVO clone() throws CloneNotSupportedException {
        MdmInsertVO clone = (MdmInsertVO) super.clone();
        return clone;
    }
}