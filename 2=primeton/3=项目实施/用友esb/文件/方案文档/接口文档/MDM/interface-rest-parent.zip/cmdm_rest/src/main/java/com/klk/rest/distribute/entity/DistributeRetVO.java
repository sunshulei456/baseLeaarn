package com.klk.rest.distribute.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.List;

/**
 * 数据分发返回体的结构
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DistributeRetVO implements Serializable {

    /**
     * 数据的血缘关系列表
     * 每条数据对应一个MdMapingVO对象
     * 必填项
     */
    private List<MdMapingVO> mdMappings;

    /**
     * 数据分发总体上是成功或失败
     * 必填项
     */
    private Boolean success;

    /**
     * 数据分发返回的详情信息
     * 必填项
     */
    private String message;

    public DistributeRetVO() {
        super();
    }

    public List<MdMapingVO> getMdMappings() {
        return mdMappings;
    }

    public void setMdMappings(List<MdMapingVO> mdMappings) {
        this.mdMappings = mdMappings;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "DistributeRetVO [mdMappings=" + mdMappings + ", success="
                + success + ", message=" + message + "]";
    }
}
