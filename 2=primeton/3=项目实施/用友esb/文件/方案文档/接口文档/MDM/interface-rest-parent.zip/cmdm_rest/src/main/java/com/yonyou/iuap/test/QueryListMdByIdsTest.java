package com.yonyou.iuap.test;

import net.sf.json.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 测试QueryListMdByIds接口的详细测试代码和说明
 */
public class QueryListMdByIdsTest {

    private void testQuery() throws IOException {
        //服务的路径，即主数据产品集成标准中提供的地址
        String url = "http://127.0.0.1:8000/iuapmdm/cxf/mdmrs/newcenter/newCenterService/queryListMdByIds";
        //人员主数据的主数据编码
        String gdCode = "person_info";
        //能够访问人员主数据的远程系统编码
        String systemCode = "system01";
        HttpPost post = new HttpPost(url);
        //HttpPost的配置
        RequestConfig requestConfig = RequestConfig.custom()
                .setSocketTimeout(60000)
                .setConnectTimeout(60000)
                .setConnectionRequestTimeout(10000)
                .build();
        //genQueryVO方法构建json结构的MdmQueryVO的json对象
        StringEntity requestEntity = new StringEntity(genQueryVO(gdCode, systemCode).toString(), "utf-8");
        requestEntity.setContentType(ContentType.APPLICATION_JSON.toString());
        post.setConfig(requestConfig);
        post.setEntity(requestEntity);
        //HttpPost的header中需要传递的两个参数

        //tenantid字段是当前系统的租户ID，若为专属化部署的主数据系统，值为tenant；若使用的是公有云的主数据系统就，值为产品的集成标准中tenantid的备注中的值
        post.setHeader("tenantid", "tenant");
        //mdmtoken是远程系统的token，也就是system01这个远程系统在主数据中设置的token
        post.setHeader("mdmtoken", "13e3cbd1-d90e-4956-8a1f-272a07ea5f2e");

        CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpResponse response = httpClient.execute(post);
        HttpEntity entity = response.getEntity();
        String resp = EntityUtils.toString(entity, "utf-8");
        System.out.println(resp);
        //返回数据
        //{"data":"[{\"person_org\":\"person_org00000001\",\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:47:30\",\"code\":\"zhangsan\",\"modifytime\":\"2019-12-21 11:47:30\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"person_org_name\":\"用友集团\",\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"person_info00000037\",\"mdm_version\":1,\"name\":\"张三\",\"id\":\"id366470330\",\"sub_job\":[{\"isHistory\":false,\"isWorkflow\":false,\"data\":{\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:47:30\",\"code\":\"lisi\",\"modifytime\":\"2019-12-21 11:47:30\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"job00000020\",\"mdm_parentcode\":\"person_info00000037\",\"job_org\":\"person_org00000001\",\"mdm_version\":1,\"name\":\"李四\",\"id\":\"id663714154\",\"job_org_name\":\"用友集团\",\"pk_mdm\":\"cd9f7a88-19a4-4a57-991c-44e538d4682b\"}}],\"pk_mdm\":\"853246de-ad48-43fb-bd72-94f96779aef0\"},{\"person_org\":\"person_org00000001\",\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:47:30\",\"code\":\"zhangsan\",\"modifytime\":\"2019-12-21 11:47:30\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"person_org_name\":\"用友集团\",\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"person_info00000038\",\"mdm_version\":1,\"name\":\"张三\",\"id\":\"id261635674\",\"sub_job\":[{\"isHistory\":false,\"isWorkflow\":false,\"data\":{\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:47:30\",\"code\":\"lisi\",\"modifytime\":\"2019-12-21 11:47:30\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"job00000021\",\"mdm_parentcode\":\"person_info00000038\",\"job_org\":\"person_org00000001\",\"mdm_version\":1,\"name\":\"李四\",\"id\":\"id724424643\",\"job_org_name\":\"用友集团\",\"pk_mdm\":\"844dac4f-ca55-45d9-82c3-8c4f7e115752\"}}],\"pk_mdm\":\"3c8ee66a-45f3-41e6-9abb-c2e1b85b2eb1\"},{\"person_org\":\"person_org00000001\",\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:48:06\",\"code\":\"zhangsan\",\"modifytime\":\"2019-12-21 11:48:06\",\"modifier\":\"datainterface\",\"mdm_datastatus\":4,\"person_org_name\":\"用友集团\",\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"person_info00000039\",\"mdm_version\":1,\"name\":\"张三\",\"id\":\"id219943341\",\"sub_job\":[{\"isHistory\":false,\"isWorkflow\":false,\"data\":{\"creator\":\"datainterface\",\"createtime\":\"2019-12-21 11:48:06\",\"code\":\"lisi\",\"modifytime\":\"2019-12-21 11:48:06\",\"modifier\":\"datainterface\",\"mdm_datastatus\":3,\"mdm_duplicate\":0,\"mdm_cleanstatus\":\"WAITING\",\"dr\":0,\"mdm_code\":\"job00000022\",\"mdm_parentcode\":\"person_info00000039\",\"job_org\":\"person_org00000001\",\"mdm_version\":1,\"name\":\"李四\",\"id\":\"id786399855\",\"job_org_name\":\"用友集团\",\"pk_mdm\":\"66e5a96a-e575-44d7-aca0-25a72c96d557\"}}],\"pk_mdm\":\"83ae390f-5d26-4043-a5d5-5cb03bb1ee87\"}]","code":null,"obj":null,"success":true,"message":null}
    }


    private JSONObject genQueryVO(String gdCode, String systemCode) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("systemCode", systemCode);
        jsonObject.put("gdCode", gdCode);
        List codes = new ArrayList();
        //这是这个查询最重要的参数，不是主数据的mdmCode，不是主数据的mdmCode，不是主数据的mdmCode
        //传递的参数为主数据的id（业务id），insertMd接口中插入数据时候，那个必须传的id
        codes.add("id366470330");
        codes.add("id261635674");
        codes.add("id219943341");
        jsonObject.put("codes", codes);
        return jsonObject;
    }

    public static void main(String[] args) {
        QueryListMdByIdsTest test = new QueryListMdByIdsTest();
        try {
            test.testQuery();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
