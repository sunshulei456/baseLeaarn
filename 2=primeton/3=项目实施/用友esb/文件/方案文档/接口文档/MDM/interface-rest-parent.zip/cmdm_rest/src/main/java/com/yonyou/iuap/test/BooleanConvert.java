package com.yonyou.iuap.test;

import com.yonyou.iuap.centerservice.entity.MapBean;

import java.util.HashMap;

public class BooleanConvert {
    public static void main(String[] args) {

        HashMap<String, Object> map = new HashMap<>();
        map.put("bool", new Boolean(false));
        map.put("str", "stringValue");
        MapBean mapBean = new MapBean();
        mapBean.setBeanMap(map);

        boolean flagBool = Boolean.valueOf(String.valueOf(mapBean.getValueByKey("bool")));
        if (flagBool) {
            System.out.println("结果为：" + flagBool);
        } else {
            System.out.println("结果为：" + flagBool);
        }
    }
}
